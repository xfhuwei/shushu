#!/bin/bash

cd `dirname $0`

#[ -t 1 ] && . colors

source colors
source h-manifest.conf
source $CUSTOM_CONFIG_FILENAME
HOSTNAME=`hostname`

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1
CUSTOM_LOG_BASEDIR=`dirname "${CUSTOM_LOG_BASENAME}"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

#if pgrep aleo-pool-prover; then
#    echo -e "${RED}aleo-pool-prover already running${NOCOLOR}"
#else
#    if [ ! -z $ADDRESS ]; then
#        ./aleo-pool-prover --account $ADDRESS --worker-name $HOSTNAME --pool $PROXY  $EXTRA 2>&1 | tee --append ${CUSTOM_LOG_BASENAME}.log
#    else
#	    echo -e "${RED}Please check the account${NOCOLOR}" && exit 1
#    fi
#fi

if [[ -z $EXTRA ]] && [[ ! -z $ADDRESS ]];then
	./aleo-pool-prover --account $ADDRESS --worker-name $HOSTNAME --pool $PROXY 2>&1 | tee --append ${CUSTOM_LOG_BASENAME}.log
elif [[ $EXTRA == "solo" ]];then
	./aleo-solo-prover --address $ADDRESS --worker-name $HOSTNAME --proxy $PROXY 2>&1 | tee --append ${CUSTOM_LOG_BASENAME}.log
else
	echo -e "${RED}Please check the extra config and account${NOCOLOR}"
	exit 1
fi
